<?php

class ProjectConfig {

    public static $project_name = "SOUTH ASIAN AUTOMOBILES (PVT) LTD.";
    public static $address = "332/29, Lessliss Land, Rathnapura Road, Munagama, Hoarana.";
    public static $tel = "Phone: +94 11 496 8030";
    public static $address_arr = array("SOUTH ASIAN AUTOMOBILES (PVT) LTD", "332/29", "Lessliss Land", "Rathnapura Road", "Munagama, Hoarana");
    public static $tel_arr = array("+94 115 883 810", "+94 115 883 811");
    public static $address_html = "332/29, Lessliss Land, Rathnapura Road, Munagama, Hoarana.";
    public static $tel_html = "+94 115 883 810 / +94 115 883 811";

//    public static $modules = array(
//        "user" => "User",
//        "privilege" => "Privilege",
//        "designation" => "Designation",
//        "target" => "Target",
//        "category" => "Category",
//        "product" => "Product",
//        "batch" => "Batch",
//        "material" => "Material",
//        "production_plan" => "Production Plan",
//        "production" => "Production",
//        "supplier" => "Supplier",
//        "customer" => "Customer",
//        "route" => "Route",
//        "product_po" => "Product PO",
//        "material_po" => "Material PO",
//        "product_po" => "Product GRN",
//        "material_po" => "Material GRN",
//        "invoice" => "Invoice",
//        "payment" => "Payment",
//        "return" => "Return",
//        "deliverer" => "Deliverer",
//        "deliverer_inventory" => "Deliverer Inventory"
//    );
}
